import ContactSection from '../portfolio/ContactSection';

export default function ContactSectionExample() {
  return (
    <div className="w-full bg-background">
      <ContactSection />
    </div>
  );
}
