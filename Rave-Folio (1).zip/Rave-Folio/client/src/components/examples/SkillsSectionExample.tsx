import SkillsSection from '../portfolio/SkillsSection';

export default function SkillsSectionExample() {
  return (
    <div className="w-full bg-background">
      <SkillsSection />
    </div>
  );
}
