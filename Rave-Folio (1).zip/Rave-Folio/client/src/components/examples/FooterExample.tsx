import Footer from '../portfolio/Footer';

export default function FooterExample() {
  return (
    <div className="w-full bg-background">
      <Footer />
    </div>
  );
}
