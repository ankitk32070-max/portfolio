import ExperienceSection from '../portfolio/ExperienceSection';

export default function ExperienceSectionExample() {
  return (
    <div className="w-full bg-background">
      <ExperienceSection />
    </div>
  );
}
