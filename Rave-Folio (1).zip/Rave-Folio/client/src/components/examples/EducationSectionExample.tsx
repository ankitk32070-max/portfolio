import EducationSection from '../portfolio/EducationSection';

export default function EducationSectionExample() {
  return (
    <div className="w-full bg-background">
      <EducationSection />
    </div>
  );
}
