import ProjectsSection from '../portfolio/ProjectsSection';

export default function ProjectsSectionExample() {
  return (
    <div className="w-full bg-background">
      <ProjectsSection />
    </div>
  );
}
