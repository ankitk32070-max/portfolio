import Navigation from '../portfolio/Navigation';

export default function NavigationExample() {
  return (
    <div className="relative w-full h-[80px] bg-background">
      <Navigation />
    </div>
  );
}
